
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split

# Load sample dataset
url = 'https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv'
df = pd.read_csv(url)

# Display initial info
print("Initial Data:")
print(df.head())

# Encode categorical columns if any
if df.select_dtypes(include='object').shape[1] > 0:
    for col in df.select_dtypes(include='object').columns:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        print(f"Encoded {col}")

# Feature scaling
scaler = StandardScaler()
scaled_features = scaler.fit_transform(df.drop('species', axis=1))
scaled_df = pd.DataFrame(scaled_features, columns=df.columns[:-1])
scaled_df['species'] = df['species']

# Train-test split
X = scaled_df.drop('species', axis=1)
y = scaled_df['species']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Save processed data
X_train.to_csv('X_train.csv', index=False)
X_test.to_csv('X_test.csv', index=False)
y_train.to_csv('y_train.csv', index=False)
y_test.to_csv('y_test.csv', index=False)

print("ETL process complete. Files saved: X_train.csv, X_test.csv, y_train.csv, y_test.csv")
