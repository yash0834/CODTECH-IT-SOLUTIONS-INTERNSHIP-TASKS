from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load pretrained model
model = joblib.load('model/model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        med_inc = float(request.form['med_inc'])
        house_age = float(request.form['house_age'])
        avg_rooms = float(request.form['avg_rooms'])
        
        # Create feature array
        features = np.array([[med_inc, house_age, avg_rooms]])
        
        # Make prediction
        prediction = model.predict(features)
        
        # Format result
        result = f"${prediction[0]*100000:,.2f}"
        
        return render_template('index.html', 
                            prediction_text=result,
                            show_result=True)
    
    except Exception as e:
        return render_template('index.html', 
                            error_message=str(e),
                            show_error=True)

if __name__ == '__main__':
    app.run(debug=True)