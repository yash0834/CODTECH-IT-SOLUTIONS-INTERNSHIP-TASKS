import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

def train_and_save_model():
    # Load processed data
    X_train = np.load('processed_data/X_train.npy')
    X_test = np.load('processed_data/X_test.npy')
    y_train = np.load('processed_data/y_train.npy')
    y_test = np.load('processed_data/y_test.npy')
    
    # Train model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Evaluate
    train_pred = model.predict(X_train)
    test_pred = model.predict(X_test)
    
    print(f"Train RMSE: {np.sqrt(mean_squared_error(y_train, train_pred)):.4f}")
    print(f"Test RMSE: {np.sqrt(mean_squared_error(y_test, test_pred)):.4f}")
    
    # Save model
    os.makedirs('model', exist_ok=True)
    joblib.dump(model, 'model/housing_model.pkl')
    print("Model trained and saved successfully")

if __name__ == "__main__":
    train_and_save_model()