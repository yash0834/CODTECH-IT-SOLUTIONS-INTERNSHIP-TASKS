# California House Price Prediction

An end-to-end data science project with Flask web interface.

## Installation

1. Clone this repository
2. Create virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`